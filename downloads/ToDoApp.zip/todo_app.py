# Simple To-Do App in Python

tasks = []

def add_task(task):
    tasks.append(task)
    print(f"Added: {task}")

def list_tasks():
    if not tasks:
        print("No tasks available.")
    else:
        print("Your Tasks:")
        for idx, task in enumerate(tasks, 1):
            print(f"{idx}. {task}")

def remove_task(index):
    try:
        removed = tasks.pop(index - 1)
        print(f"Removed: {removed}")
    except IndexError:
        print("Invalid task number.")

while True:
    print("\nOptions: 1. Add Task  2. View Tasks  3. Remove Task  4. Exit")
    choice = input("Choose an option: ")

    if choice == "1":
        task = input("Enter a task: ")
        add_task(task)
    elif choice == "2":
        list_tasks()
    elif choice == "3":
        list_tasks()
        try:
            index = int(input("Enter task number to remove: "))
            remove_task(index)
        except ValueError:
            print("Please enter a valid number.")
    elif choice == "4":
        print("Goodbye!")
        break
    else:
        print("Invalid option. Try again.")
