// Simple Student Management System in Java
import java.util.ArrayList;
import java.util.Scanner;

class Student {
    String name;
    int id;
    
    Student(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public String toString() {
        return "ID: " + id + ", Name: " + name;
    }
}

public class StudentManagementSystem {
    static ArrayList<Student> students = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);
    
    public static void addStudent() {
        System.out.print("Enter Student ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        students.add(new Student(id, name));
        System.out.println("Student added successfully!");
    }
    
    public static void viewStudents() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
        } else {
            System.out.println("Student List:");
            for (Student s : students) {
                System.out.println(s);
            }
        }
    }
    
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Add Student  2. View Students  3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            
            switch (choice) {
                case 1 -> addStudent();
                case 2 -> viewStudents();
                case 3 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
